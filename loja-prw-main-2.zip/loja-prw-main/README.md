## Anotações

- Baixar todas as imagens dos produtos p nao depender de um link online
- ~~Fazer uma pasta pras imagens e mudar o src~~ *(fiz)*
- Se atentar às cores
- Melhorar o css num geral socorro
- limitar os campos de cpf data cep etc
- fazer header e footer em arquivos separados

## Trabalho 2

1. ~~Criar um único arquivo CSS para toda a plataforma (para todas as páginas);~~ *(já temos!)*
2. Página inicial do site contendo campo para busca de produtos: implementar um
autocomplete para os nomes dos produtos;
3. Página de login com usuário e senha: se o usuário não digitar o usuário e a senha,
deve exibir um alerta em um div: “É necessário digitar usuário e senha para
prosseguir” (ao digitar os dados solicitados, a mensagem deve desaparecer
quando clicar no botão);
4. Página de cadastro de usuário: se o usuário não digitar todas as informações,
exibir um alerta via div (ou divs) informando o que faltou ser digitado (exemplos:
faltou digitar o nome ou faltou digitar a senha) e, ao digitar os dados solicitados, a
mensagem deve desaparecer quando clicar no botão;
5. Página com informações de um produto: ao selecionar a quantidade (para mais ou
para menos), deve calcular e exibir o valor parcial na página;
6. Página contendo um carrinho de compras: totalmente funcional podendo alterar a
quantidade de um dos três produtos e já mostrar o total parcial na tela (por
exemplo: 2 calças de R$ 110,00 cada totalizam R$ 220,00), digitar um CEP e
calcular o valor do frete (deve aceitar os CEPs de Garopaba, Imbituba e Paulo
Lopes), atualização constante do valor total da compra e inclusão de um campo
para digitar um cupom (devem ter 2 tipos de cupom disponíveis: um que dá
desconto no valor total e outro que dá frete grátis independente do valor);
7. Outras páginas que a dupla julgar necessária para o site: implementar scripts se
necessário (opcional).
