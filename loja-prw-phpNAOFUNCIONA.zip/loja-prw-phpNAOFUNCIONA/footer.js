document.writeln
(`
  <div id="footer">
    <div>
      <p>Card Shop</p>
      <a href="#">Instagram</a>
      <a href="#">Facebook</a>
    </div>
    <div>
      <p>contato@cardshop.com</p>
      <p>+55 (00) 00000-0000</p>
    </div>
  </div>
`);