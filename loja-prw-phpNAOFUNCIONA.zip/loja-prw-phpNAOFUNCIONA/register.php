<?php
//inclui o arquivo de conexao
include "connect.php";

//verifica se o form enviou os dados com post
if ($_SERVER["REQUEST_METHOD"] == "POST"){
    //recebe os dados
    $nome = $_POST['name'];
    $email = $_POST['mail'];

    //validacao: nao estao vazios
    if (!empty($nome) && !empty($email)){
        //perpara o SQL p evitar SQL Injection???
        $stmt = $conn->prepare("INSERT INTO usuarios (nome, email) VALUES (?, ?)");
        $stmt->bind_param("ss", $nome, $email);

        //executa o sql e verifica se ta funcionando
        if ($stmt->execute()){
            echo "<p>Usuário cadastrado com sucesso!</p>";
        }else{
            echo "<p>Erro ao inserir registro: " . $stmt->error . "</p>";
        }
        //fecha a consulta
        $stmt->close();
    }else{
        echo "<p>Erro: Por favor, preencha todos os campos.</p>";
    }
}
//fecha a conexão com o mariaDB - importante!!!!!!!
$conn->close();