<?php

// configuracoes p coneccao banco de dados
$servername = "localhost"; // endereço do servidor
$username = "root"; //usuario do banco
$password = ""; //senha do banco - padrao é em branco
$dbname = "meu_banco"; //nome do banco

//cria a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

//verifica a conexao
if ($conn->connect_error){
    die("Conexão falhou: " . $conn->connect_error);
}

?>