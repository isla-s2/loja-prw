function preco_atual(){
    let item = this.closest("li");
    let input = item.getElementsByClassName('quantity')[0];
    if (input.value <1){
        input.value = 1;
    }
    item.getElementsByClassName('prodTotal')[0].innerHTML = (parseFloat(item.getElementsByClassName('price')[0].innerHTML.replace(',', '.'))*input.value).toFixed(2).replace('.', ',');
    total();
}

function excluir(){
    this.closest("li").remove();
    total();
}

var botoes = document.getElementsByClassName('delete');
for (let i=0; i<botoes.length; i++){
    botoes[i].addEventListener('click', excluir);
}

var inputs = document.getElementsByClassName('quantity');
for (let i=0; i<inputs.length; i++){
    inputs[i].addEventListener('change', preco_atual);
}

function total(){
    let precos = document.getElementsByClassName('prodTotal');
    let total = 0;
    for (let p of precos){
        total += parseFloat(p.innerHTML.replace(',', '.'))
    }
    total += parseFloat(document.getElementById('valorFrete').innerHTML.replace(',', '.'));
    document.getElementById('totalCarrinho').innerHTML = total.toFixed(2).replace('.', ',');
}

function frete(){
    let valor_f = 0;
    switch (document.getElementById('cep').value){
        case '88780-000':
            valor_f= 14;
            break;
        case '88495-000':
            valor_f= 15;
            break;
        case '88490-000':
            valor_f= 16;
            break;
    }
    let total_f = parseFloat(this.label.getElementsByClassName('s_price')[0]);
    document.getElementById('')
    total();
}
document.getElementById('calcularFrete').addEventListener('click', frete);