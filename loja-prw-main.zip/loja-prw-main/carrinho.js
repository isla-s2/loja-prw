function preco_atual(){
    item = this.closest("li");
    input = item.getElementsByTagName('quantity')[0];
    if (input.value <1){
        input.value = 1;
    }
    item.getElementsByClassName('prodTotal')[0].innerHTML = (parseFloat(item.getElementsByTagName('price')[0].innerHTML)*input.value).toFixed(2);
    total();
}

function excluir(){
    this.closest("li").remove();
    total();
}

var botoes = document.getElementsByClassName('delete');
for (let i=0; i<botoes.length; i++){
    botoes[i].addEventListener('click', excluir);
}

function total(){
    let precos = document.getElementsByClassName('prodTotal');
    let total = 0;
    for (let p of precos){
        total += parseFloat(p.innerHTML.replace(',', '.'))
    }
    total += parseFloat(document.getElementById('valorFrete').innerHTML.replace(',', '.'));
    document.getElementById('totalCarrinho').innerHTML = total.toFixed(2).replace('.', ',');
}

function frete(){
    switch (document.getElementById('cep').value){
        case '88780-000':
            document.getElementById('valorFrete').innerHTML = "14,00";
            break;
        case '88495-000':
            document.getElementById('valorFrete').innerHTML = "15,00";
            break;
        case '88490-000':
            document.getElementById('valorFrete').innerHTML = "16,00";
            break;
    }
    total();
}
document.getElementById('calcularFrete').addEventListener('click', frete);