document.writeln
(`<div id="top">
      <a href="index.html" id="logo">
        <img src="img/Card.png">
        <h1>Card Shop</h1>
      </a>

      <search>
        <form autocomplete="off">
          <input name="fsrch" id="fsrch">
          <input type="image" id="mglass" src="https://cdn-icons-png.flaticon.com/256/51/51658.png">
        </form>
      </search>

      <ul>
        <li><a href="#">Sobre Nós</a></li>

        <li><a href="login.html">
          <img src="img/Profile.png">
          <span>Conta</span>
        </a></li>

        <li><a href="cart.html">
          <div id="cart_icon">
            <img src="img/Carrinho.png">
            <strong>8</strong>
          </div>
          <div id="cart_text">
            <span>Carrinho</span>
            <span>R$ 2949,92</span>
          </div>
        </a></li>
      </ul>
    </div>`);